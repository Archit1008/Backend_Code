package com.ADmy.spring.boot.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Arrays;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import com.ADmy.UserData.Entity.User;
import com.ADmy.UserData.exception.UserAlreadyExistException;
import com.ADmy.UserData.repository.UserRepository;
import com.ADmy.UserData.service.UserService;
@ExtendWith(MockitoExtension.class)// for instantiate mocking
public class UserServiceTest {
	@Mock
	private UserRepository userRepository;
	@Autowired
	@InjectMocks
	private UserService userService;
	 User user1;
	 User user2;
	 User user3;
	 User user4;
	 List<User> userList;
	 
	 @BeforeEach
	 public void setUp() {
		 user1= new User("1","Ram","02-09-1990","ward 14 rampur ","Biodata","22-09-20022");
		 user2= new User("2","Shyam","05-09-1990","ward 14 rampur ","Biodata","22-09-20022");
		 user3= new User("3","Balram","012-09-1990","ward 14 rampur ","Biodata","22-09-20022");
	  userList= Arrays.asList(user1,user2,user3);
	 }
	 

	@AfterEach
	public void tearDown() {
		user1=user2=user3=null;
		userList=null;
	}
	@Test
	@DisplayName("save-user-test")//save data on database
	public void given_Employee_To_Save_Shoukd_Return_The_Saved_User() throws UserAlreadyExistException {
		when(userRepository.findById(any())).thenReturn(null);
		when(userRepository.save(any())).thenReturn(user1);
		User savedUser= userService.saveUser(user1);
		assertNotNull(savedUser);
		assertEquals("1",savedUser.getId());
		
	}
	

}
