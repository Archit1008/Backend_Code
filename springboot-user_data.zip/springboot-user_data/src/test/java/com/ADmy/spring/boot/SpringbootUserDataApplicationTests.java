package com.ADmy.spring.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import com.ADmy.UserData.SpringbootUserDataApplication;
//springbootioc all test managementment class 
@SpringBootConfiguration
@SpringBootTest(classes= SpringbootUserDataApplication.class)
class SpringbootUserDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
