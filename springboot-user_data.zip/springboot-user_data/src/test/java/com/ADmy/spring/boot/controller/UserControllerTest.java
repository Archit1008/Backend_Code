 package com.ADmy.spring.boot.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when; 
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.Arrays;
import java.io.IOException;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.ADmy.UserData.Entity.User;
import com.ADmy.UserData.controller.UserController;
import com.ADmy.UserData.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
//we can test controller layer on this class
@ExtendWith(MockitoExtension.class)
public class UserControllerTest {
	@Mock //mocking user service 
	private UserService userService;
	
	@Autowired
	@InjectMocks//we want to inject mocked userservice to controller so we use inject mocked
	private UserController userController;
	 User user1;
	 User user2;
	 User user3;
	 User user4;
	 List<User> userList;

	private MockMvc mockMvc;
	 
	 @BeforeEach
	 public void setUp() {
		 user1= new User("1","Ram","02-09-1990","ward 14 rampur ","Biodata","22-09-20022");
		 user2= new User("2","Shyam","05-09-1990","ward 14 rampur ","Biodata","22-09-20022");
		 user3= new User("3","Balram","012-09-1990","ward 14 rampur ","Biodata","22-09-20022");
	  userList= Arrays.asList(user1,user2,user3);
	    mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
	 }
	 

	@AfterEach
	public void tearDown() {
		user1=user2=user3=null;
		userList=null;
	}
	@Test
	@DisplayName("save-controller-test")
	public void given_User_To_save_User_Should_Return_User_As_JSON_With_Status_Created() throws Exception {
		when(userService.saveUser(any())).thenReturn(user1);

		mockMvc = null;
		mockMvc.perform(post("/api/v1/Users/user").contentType(MediaType.APPLICATION_JSON).content(asJsonString(user1)))//for mapping end points
		.andExpect(status().isCreated());//expecting status code
	}
	public static String asJsonString(Object obj)//wrapper method 
	{
		ObjectMapper object = new ObjectMapper();
		String jsonstr=null;
		try {
			String jsonStr=object.writeValueAsString(object);
			System.out.println(jsonStr);
			return jsonStr;
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return jsonstr;
		
	}
 
}
