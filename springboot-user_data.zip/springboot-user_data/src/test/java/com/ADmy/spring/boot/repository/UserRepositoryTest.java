package com.ADmy.spring.boot.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Arrays;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ADmy.UserData.Entity.User;
import com.ADmy.UserData.repository.UserRepository;
//here we can test Repository layer
@ExtendWith(SpringExtension.class)//support class for define annotation
@DataJpaTest//datajpatest annotation used for send data on in memory database
public class UserRepositoryTest {
	@Autowired//for auto injecting dependency
	 private UserRepository userRepository;
	 User user;
	 User user1;
	 User user2;
	 User user3;
	 User user4;
	 List<User> userList;
	 
	 @BeforeEach//before run test case we want to pass dumy data to entity
	 public void setUp() {
		 user1= new User("1","Ram","02-09-1990","ward 14 rampur ","Biodata","22-09-20022");
		 user2= new User("2","Shyam","05-09-1990","ward 14 rampur ","Biodata","22-09-20022");
		 user3= new User("3","Balram","012-09-1990","ward 14 rampur ","Biodata","22-09-20022");
	  userList= Arrays.asList(user1,user2,user3);
	 }
	 

	@AfterEach//after run test case we want to drop or delete data
	public void tearDown() {
		user1=user2=user3=null;
		userRepository.deleteAll();
		userList=null;
	}
	@Test//now here we pass  different test case
	@DisplayName("save-user-test")
	public void given_User_To_Save_Should_Return_The_saved_User() {
		userRepository.save(user1);
		User savedUser= userRepository.findById(user1.getId()).get();
		assertEquals("Ram",savedUser.getName());
		
	}
	@Test
	@DisplayName("get-user-list-test")
	public void given_GetAllUsers_Should_Return_Users_List() {
		userRepository.save(user1);
		userRepository.save(user2);
		userRepository.save(user3);
		List<User> userList= userRepository.findAll();
		assertEquals(2,userList.size());
		assertEquals("Ram",userList.get(0).getName());
	}
	@Test
	@DisplayName("get-user-non-existing-id-test")
	public void given_Non_Existing_Id_Should_Return_Optional_Empty(){
		userRepository.save(user1);
		assertThat(userRepository.findById("2")).isEmpty();
		
	}
}


