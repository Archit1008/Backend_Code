package com.ADmy.UserData.Entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
// entity class to store the data
@Document
public class User {
	public User(String id, String name, String dob, String address, String description, String createdAt) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.address = address;
		this.description = description;
		this.createdAt = createdAt;
	}
	@Id
	private String id;
	private String name;
	private String dob;
	private String address;
	private String description;
	private String createdAt;
	public User() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String test) {
		this.name = test;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", dob=" + dob + ", address=" + address + ", description="
				+ description + ", createdAt=" + createdAt + "]";
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	
	

}
