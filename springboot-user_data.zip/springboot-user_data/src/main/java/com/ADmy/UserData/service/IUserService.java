package com.ADmy.UserData.service;

import java.util.ArrayList;
import com.ADmy.UserData.Entity.User;
import com.ADmy.UserData.exception.UserAlreadyExistException;
import com.ADmy.UserData.exception.UserNotFoundException;
//declare that interface to show enough thing to user  and hide that  definition methods
public interface IUserService {
	public User saveUser(User user) throws UserAlreadyExistException ;
	public ArrayList<User> getUserData();
	public User getUserDataById(String userid) throws UserNotFoundException;
	public User updateUserData(User user) throws UserNotFoundException;
	public boolean deleteUserData(String userid) throws UserNotFoundException;
	
}
