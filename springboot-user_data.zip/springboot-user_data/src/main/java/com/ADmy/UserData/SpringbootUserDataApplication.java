package com.ADmy.UserData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//Spring Ioc Controller Class which  controll amd manage whole application
public class SpringbootUserDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootUserDataApplication.class, args);
	}

}
