package com.ADmy.UserData.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ADmy.UserData.Entity.User;

@Repository//i declared the repository interface to perform crud operation  on database by the help mongo repository
//and mongo repository provide predefined methods for perform manipulation on database
public interface UserRepository extends MongoRepository<User,String> {

}
