package com.ADmy.UserData.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ADmy.UserData.Entity.User;
import com.ADmy.UserData.exception.UserAlreadyExistException;
import com.ADmy.UserData.exception.UserNotFoundException;
import com.ADmy.UserData.repository.UserRepository;
@Service//we can make service and that service are make communication to repository as well as controller
public class UserService  implements IUserService{
     @Autowired
     private UserRepository userRepository;
     //here we can perform crud operation on database with the help of repository 
	@Override
	public User saveUser(User user) throws  UserAlreadyExistException  {
		// TODO Auto-generated method stub
		User userResponse =null;
		Optional<User> find= this.userRepository.findById(user.getId());
		if(find.isPresent()) {
			 throw new UserAlreadyExistException() ;
			 }
		else{
			userResponse = userRepository.save(user);
			}
		
		
		return userResponse;
	}

	@Override
	public ArrayList<User> getUserData() {
		// TODO Auto-generated method stub
		ArrayList<User> userData = new ArrayList<>();
		userRepository.findAll().forEach(userData::add);		
		return userData;
	}

	@Override
	public User getUserDataById(String userid) throws UserNotFoundException {
		// TODO Auto-generated method stub
		User userResponse=null;
		Optional<User> find= userRepository.findById(userid);
		if(find.isPresent()) {
			userResponse= find.get();
		}
		else{
			throw new UserNotFoundException();
			
}
		
		return userResponse;
	}

	@Override
	public User updateUserData(User user) throws UserNotFoundException {
		// TODO Auto-generated method stub
		User userResponse=null;
		Optional<User> find= userRepository.findById(user.getId());
		if(find.isPresent()) {
			 userResponse= userRepository.save(user);
			 }
		else{
			throw new UserNotFoundException();
			}
		
		
		return userResponse;
	}

	@Override
	public boolean deleteUserData(String userid) throws UserNotFoundException {
		// TODO Auto-generated method stub
		boolean userResponse= false;
		Optional<User> find= userRepository.findById(userid);
		if(find.isPresent()) {
			 this.userRepository.deleteById(userid);
			 userResponse=true;
		}
		else{
			throw new UserNotFoundException();
			
}
		
		return userResponse;
	}

}
