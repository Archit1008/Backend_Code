package com.ADmy.UserData.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ADmy.UserData.Entity.User;
import com.ADmy.UserData.exception.UserAlreadyExistException;
import com.ADmy.UserData.exception.UserNotFoundException;
import com.ADmy.UserData.service.UserService;

@RestController
@RequestMapping("api/v1/UserData")//this annotation use use map end point to user
public class UserController {
	@Autowired
	private UserService userService;
	 @PostMapping("/user")// use post mappinng to save data
	 public ResponseEntity<?> saveUser(@RequestBody User user) throws UserAlreadyExistException {
		 ResponseEntity<?> responseEntity= null;
		 try {
			 User responseuser = userService.saveUser(user);
			 responseEntity= new ResponseEntity<> (responseuser,HttpStatus.CREATED);// i can use Httastaus for getting code
		 }
		catch(UserAlreadyExistException e) {
			throw e;
		}
	         return responseEntity;
		 
	 }
	 @GetMapping("/user")//using getmapping to get list of user data
	 public ResponseEntity<?> getUserData()  {
	     ResponseEntity<?> responseEntity=null;
	     try {
		 ArrayList<User> userdata = userService.getUserData();
		 if(userdata!=null) {
			 responseEntity= new ResponseEntity<>(userdata,HttpStatus.OK);
		 }
		 else {
			 responseEntity= new ResponseEntity<>(HttpStatus.NOT_FOUND);
		 }
	     }
	     catch(Exception e) {
				responseEntity = new ResponseEntity<>("some iternal error occurs",HttpStatus.INTERNAL_SERVER_ERROR);// if internal server error is occur then we can throw the error
				throw e;
			}
		 return responseEntity;
	 }
	     
	 @GetMapping("/user/{userid}")
	 public ResponseEntity<?> getUserDataById(@PathVariable("userid") String userId) throws UserNotFoundException{
		 ResponseEntity<?> responseEntity=null;
		 try {
		 User respondeUserData = userService.getUserDataById(userId);
		  responseEntity=  new ResponseEntity<>(respondeUserData,HttpStatus.OK);
				 }
		 catch(UserNotFoundException e) {
			 throw e;
		 }
		 catch(Exception e) {
				responseEntity = new ResponseEntity<>("some iternal error occurs",HttpStatus.INTERNAL_SERVER_ERROR);
				throw e;
			}
		 return responseEntity;
		 
	 }
	 @PutMapping("/user") // put for update data
	 public ResponseEntity<?> updateUserData(@RequestBody User user) throws UserNotFoundException{ //use throws keyword for throw the error 
		 ResponseEntity<?> responseEntity= null;
		 try {
			 User responseuser = userService.updateUserData(user);
			 responseEntity= new ResponseEntity<> (responseuser,HttpStatus.OK);
		 }
		 catch(UserNotFoundException e) {
			 throw e;
			  }
		 catch(Exception e) {
				responseEntity = new ResponseEntity<>("some iternal error occurs",HttpStatus.INTERNAL_SERVER_ERROR);
				throw e;
			}
		 return responseEntity;
		}
	 @DeleteMapping("/user/{userid}")
	 public  ResponseEntity<?> deleUserData(@PathVariable("userid") String userId) throws UserNotFoundException{
		 ResponseEntity<?> responseEntity=null;
		 try {
		 boolean respondeUserData = userService.deleteUserData(userId);
		  responseEntity=  new ResponseEntity<>(respondeUserData,HttpStatus.OK);
				 }
		 catch(UserNotFoundException e) {
			 throw e;
		 }
		 catch(Exception e) {
				responseEntity = new ResponseEntity<>("some iternal error occurs",HttpStatus.INTERNAL_SERVER_ERROR);
				throw e;
			}
		 return responseEntity;
		 
	 }
}
